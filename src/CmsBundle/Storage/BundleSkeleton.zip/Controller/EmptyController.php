<?php
namespace App\Trinity\EmptyBundle\Controller;

use App\CmsBundle\Controller\StorageController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

// Custom form elements
// 

class EmptyController extends StorageController
{

    /**
     * @Route("/admin/empty", name="admin_mod_empty")
     * @Template()
     */
    public function index( Request $request, $id = null)
    {
        // Initialize StorageController
        parent::init($request);

        $this->breadcrumbs->addRouteItem('Nieuwe bundel', 'admin_mod_empty');

        return $this->attributes([
            // Variables
        ]);
    }

    /**
     * Show bundle content to front
     *
     * @param  array  $config Array with configuration options
     * @param  array  $params Additional parameters
     *
     * @return string         HTML
     */
    public function showAction($config, $params = [], $request)
    {
        parent::init($request);
        
        // Call for template to show on website when this module is linked to a page.
        // You can do whatever you want in this function, just return data as below, extend the 'renderView' function with variables when required.
        return $this->renderView('@TrinityEmpty/default/front.html.twig', [
            // Variables
            'params' => $params,
        ]);
    }

    /**
     * Return link data when required within the link form
     *
     * @param  object  Doctrine object
     *
     * @return array   Array with config options
     */
    public function getLinkData($em){
        return [
            // Return data to link form
        ];
    }

    /**
     * Show dashboard blocks
     *
     * @return array List of blocks
     */
    public function dashboardBlocks(){
        // Return block data to show on Trinity dashboard in the following format.
        // You can do whatever you want in this function, just return data as below.
        return [
            [

                'title' => 'Mijn lege module',
                'class' => '',
                'content' => '<div style="text-align:center;padding:20px;">Lege module</div>'
            ]
        ];
    }
}
