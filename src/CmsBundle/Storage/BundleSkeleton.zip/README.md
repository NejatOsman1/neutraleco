New skeleton bundle
