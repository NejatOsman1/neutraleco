<?php

namespace App\Trinity\EmptyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TrinityEmptyBundle extends Bundle
{
}
